"""
Altitude vs. Speed (as Mach number) - XY scatter plots

1. Reads alt_vs_speed.csv (Altitude in feet, Speed in mph).
2. Converts speed from mph to Mach number.
3. Draws an XY scatter plot of altitude vs. Mach, colored warm (low altitude)
   to cold (high altitude), with a trend line.

Reference: https://airplaneacademy.com/do-airplanes-fly-faster-at-higher-altitudes/
That article gives Mach 1 as about 767 mph (667 knots), so Plot 1 uses
    Mach = speed_mph / 767

UNIQUE ELEMENT: Plot 2 corrects for altitude. The speed of sound really
depends on air temperature, and air gets colder as you climb (standard
atmosphere), so Mach 1 is slower at altitude than at sea level.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import colormaps
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable

CSV_FILE = "alt_vs_speed.csv"
MACH_1_MPH = 767  # from the reference article (sea-level speed of sound)

# ---------- 1. Read and clean ----------
df = pd.read_csv(CSV_FILE).dropna()
altitude_ft = df["Altitude(ft)"].to_numpy()
speed_mph = df["Speed(mph)"].to_numpy()
print(f"Using {len(df)} valid rows")


# ---------- 2. Convert mph to Mach ----------
def mach_simple(speed):
    """Mach number using one fixed Mach 1 (767 mph), as in the reference."""
    return speed / MACH_1_MPH


def speed_of_sound_mph(alt_ft):
    """Speed of sound (mph) at an altitude using the standard atmosphere.

    Temperature falls 6.5 C per 1000 m up to 11,000 m (about 36,089 ft),
    then stays at 216.65 K. Speed of sound = sqrt(1.4 * 287.05 * T) in m/s.
    """
    alt_m = alt_ft * 0.3048
    temp_k = np.where(alt_m <= 11000, 288.15 - 0.0065 * alt_m, 216.65)
    a_ms = np.sqrt(1.4 * 287.05 * temp_k)
    return a_ms / 0.44704  # m/s -> mph


mach_ref = mach_simple(speed_mph)
mach_adj = speed_mph / speed_of_sound_mph(altitude_ft)

# ---------- 3. Shared color setup: warm (low) -> cold (high) ----------
cmap = colormaps["coolwarm_r"]
norm = Normalize(vmin=0, vmax=40000)


def scatter_plot(mach, title, filename, ylabel):
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.scatter(altitude_ft, mach, c=altitude_ft, cmap=cmap, norm=norm,
               edgecolor="black", linewidth=0.3, alpha=0.8)

    # Trend line (curve, degree 2)
    trend = np.poly1d(np.polyfit(altitude_ft, mach, 2))
    r2 = 1 - np.sum((mach - trend(altitude_ft)) ** 2) / np.sum((mach - mach.mean()) ** 2)
    x_line = np.linspace(altitude_ft.min(), altitude_ft.max(), 200)
    ax.plot(x_line, trend(x_line), color="black", linewidth=2,
            label=f"Trend line (R\u00b2 = {r2:.2f})")

    ax.axhline(1.0, color="gray", linestyle="--", label="Mach 1 (speed of sound)")
    ax.set_title(title)
    ax.set_xlabel("Altitude (feet)")
    ax.set_ylabel(ylabel)
    ax.grid(alpha=0.3)
    ax.legend(loc="upper left")
    fig.colorbar(ScalarMappable(norm=norm, cmap=cmap), ax=ax, label="Altitude (ft)")
    plt.tight_layout()
    plt.savefig(filename, dpi=150)


scatter_plot(mach_ref,
             "Altitude vs. Speed (Mach = mph / 767)",
             "alt_vs_mach_scatter.png",
             "Speed (Mach number)")

scatter_plot(mach_adj,
             "Altitude vs. Speed (Mach adjusted for temperature at altitude)",
             "alt_vs_mach_adjusted.png",
             "Speed (Mach number, altitude-adjusted)")

print(f"Max Mach (fixed 767 mph): {mach_ref.max():.2f}")
print(f"Max Mach (altitude-adjusted): {mach_adj.max():.2f}")
plt.show()
